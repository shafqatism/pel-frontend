"use client"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useEffect } from "react"
import { fleetApi } from "@/lib/api/fleet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { useAppDispatch } from "@/lib/store"
import { closeFleetDrawer } from "@/lib/store/slices/ui-slice"
import { Loader2 } from "lucide-react"

const schema = z.object({
  registrationNumber: z.string().min(1, "Registration is required"),
  vehicleName: z.string().min(1, "Name is required"),
  make: z.string().optional(),
  model: z.string().optional(),
  year: z.preprocess((val) => Number(val), z.number().min(1900).max(2100)).optional(),
  type: z.string().default("suv"),
  fuelType: z.string().default("petrol"),
  ownershipStatus: z.string().default("company_owned"),
  status: z.string().default("active"),
  assignedSite: z.string().optional().nullable(),
  currentDriverName: z.string().optional().nullable(),
  currentOdometerKm: z.preprocess((val) => Number(val), z.number()).default(0),
})

type FormData = z.infer<typeof schema>

export default function VehicleForm({ data, mode }: { data?: any; mode: 'create' | 'edit' }) {
  const qc = useQueryClient()
  const dispatch = useAppDispatch()

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      registrationNumber: "", vehicleName: "", type: "suv",
      fuelType: "petrol", ownershipStatus: "company_owned", status: "active",
      currentOdometerKm: 0
    }
  })

  useEffect(() => {
    if (data && mode === 'edit') {
      reset({
        registrationNumber: data.registrationNumber || "",
        vehicleName: data.vehicleName || "",
        make: data.make || "",
        model: data.model || "",
        year: data.year || undefined,
        type: data.type || "suv",
        fuelType: data.fuelType || "petrol",
        ownershipStatus: data.ownershipStatus || "company_owned",
        status: data.status || "active",
        assignedSite: data.assignedSite || "",
        currentDriverName: data.currentDriverName || "",
        currentOdometerKm: data.currentOdometerKm || 0,
      })
    } else {
      reset({
        registrationNumber: "", vehicleName: "", type: "suv",
        fuelType: "petrol", ownershipStatus: "company_owned", status: "active",
        currentOdometerKm: 0
      })
    }
  }, [data, mode, reset])

  const { mutate, isPending } = useMutation({
    mutationFn: (vals: FormData) => 
      mode === 'create' ? fleetApi.vehicles.create(vals as any) : fleetApi.vehicles.update(data.id, vals as any),
    onSuccess: () => {
      toast.success(mode === 'create' ? "Vehicle registered" : "Vehicle updated")
      qc.invalidateQueries({ queryKey: ["vehicles"] })
      dispatch(closeFleetDrawer())
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.message || "Something went wrong")
    }
  })

  return (
    <form onSubmit={handleSubmit(v => mutate(v))} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Registration Number *</Label>
          <Input {...register("registrationNumber")} placeholder="LEA-1234" />
          {errors.registrationNumber && <p className="text-xs text-destructive">{errors.registrationNumber.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Vehicle Name *</Label>
          <Input {...register("vehicleName")} placeholder="Toyota Hilux" />
          {errors.vehicleName && <p className="text-xs text-destructive">{errors.vehicleName.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Vehicle Type</Label>
          <Select value={watch("type")} onValueChange={v => setValue("type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["sedan","suv","pickup","truck","bus","van","motorcycle","heavy_equipment"].map(t => (
                <SelectItem key={t} value={t}>{t.replace("_"," ")}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Fuel Type</Label>
          <Select value={watch("fuelType")} onValueChange={v => setValue("fuelType", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["petrol","diesel","cng","electric","hybrid"].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Status</Label>
          <Select value={watch("status")} onValueChange={v => setValue("status", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {["active","in_maintenance","inactive","decommissioned"].map(t => (
                <SelectItem key={t} value={t}>{t.replace("_"," ")}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Current Odometer (km)</Label>
          <Input type="number" {...register("currentOdometerKm")} />
        </div>
        <div className="space-y-1.5">
          <Label>Assigned Site</Label>
          <Input {...register("assignedSite")} />
        </div>
        <div className="space-y-1.5">
          <Label>Driver Name</Label>
          <Input {...register("currentDriverName")} />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={() => dispatch(closeFleetDrawer())}>Cancel</Button>
        <Button type="submit" disabled={isPending}>
          {isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {mode === 'create' ? "Register Vehicle" : "Save Changes"}
        </Button>
      </div>
    </form>
  )
}
