"use client"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { useEffect } from "react"
import { fleetApi } from "@/lib/api/fleet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { useAppDispatch } from "@/lib/store"
import { closeFleetDrawer } from "@/lib/store/slices/ui-slice"
import { Loader2 } from "lucide-react"

const schema = z.object({
  vehicleId: z.string().min(1, "Vehicle is required"),
  maintenanceDate: z.string().min(1, "Date is required"),
  type: z.string().default("routine_check"),
  description: z.string().optional().nullable(),
  costPkr: z.preprocess(Number, z.number().nonnegative()),
  shopOrPerson: z.string().optional().nullable(),
  odometerAtMaintenanceKm: z.preprocess(Number, z.number().nonnegative()),
  nextServiceOdometerKm: z.preprocess((v) => v === "" || v === null ? undefined : Number(v), z.number().optional().nullable()),
  nextServiceDueDate: z.string().optional().nullable(),
  maintenanceBy: z.string().default("internal"),
})
type FormData = z.infer<typeof schema>

const MAINTENANCE_TYPES = [
  "routine_check", "oil_change", "tire_change", "brake_service",
  "engine_repair", "electrical_repair", "ac_service", "body_repair", "other"
]

export default function MaintenanceForm({ data, mode }: { data?: any; mode: 'create' | 'edit' }) {
  const qc = useQueryClient()
  const dispatch = useAppDispatch()
  const { data: vehicles } = useQuery({ queryKey: ["vehicles", "dropdown"], queryFn: fleetApi.vehicles.dropdown })

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      vehicleId: "", maintenanceDate: new Date().toISOString().split("T")[0],
      type: "routine_check", costPkr: 0, odometerAtMaintenanceKm: 0, maintenanceBy: "internal"
    }
  })

  useEffect(() => {
    if (data && mode === 'edit') {
      reset({
        vehicleId: data.vehicleId || data.vehicle?.id || "",
        maintenanceDate: data.maintenanceDate ? new Date(data.maintenanceDate).toISOString().split("T")[0] : "",
        type: data.type || "routine_check",
        description: data.description || "",
        costPkr: data.costPkr || 0,
        shopOrPerson: data.shopOrPerson || "",
        odometerAtMaintenanceKm: data.odometerAtMaintenanceKm || 0,
        nextServiceOdometerKm: data.nextServiceOdometerKm,
        nextServiceDueDate: data.nextServiceDueDate ? new Date(data.nextServiceDueDate).toISOString().split("T")[0] : "",
        maintenanceBy: data.maintenanceBy || "internal",
      })
    } else {
      reset({
        vehicleId: "", maintenanceDate: new Date().toISOString().split("T")[0],
        type: "routine_check", costPkr: 0, odometerAtMaintenanceKm: 0, maintenanceBy: "internal"
      })
    }
  }, [data, mode, reset])

  const { mutate, isPending } = useMutation({
    mutationFn: (vals: FormData) =>
      mode === 'create' ? fleetApi.maintenance.create(vals as any) : fleetApi.maintenance.update(data.id, vals as any),
    onSuccess: () => {
      toast.success(mode === 'create' ? "Maintenance record created" : "Record updated")
      qc.invalidateQueries({ queryKey: ["maintenance"] })
      dispatch(closeFleetDrawer())
    },
    onError: (err: any) => toast.error(err.response?.data?.message || "Something went wrong"),
  })

  return (
    <form onSubmit={handleSubmit(v => mutate(v))} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 space-y-1.5">
          <Label>Vehicle *</Label>
          <Select value={watch("vehicleId")} onValueChange={v => setValue("vehicleId", v)}>
            <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
            <SelectContent>
              {vehicles?.map(v => (
                <SelectItem key={v.id} value={v.id}>{v.registrationNumber} — {v.vehicleName}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.vehicleId && <p className="text-xs text-destructive">{errors.vehicleId.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Maintenance Type *</Label>
          <Select value={watch("type")} onValueChange={v => setValue("type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {MAINTENANCE_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Date *</Label>
          <Input type="date" {...register("maintenanceDate")} />
        </div>
        <div className="space-y-1.5">
          <Label>Cost (PKR) *</Label>
          <Input type="number" step="0.01" {...register("costPkr")} />
        </div>
        <div className="space-y-1.5">
          <Label>Odometer at Service (km)</Label>
          <Input type="number" {...register("odometerAtMaintenanceKm")} />
        </div>
        <div className="col-span-2 space-y-1.5">
          <Label>Description</Label>
          <Textarea {...register("description")} placeholder="Details about the work done..." rows={3} />
        </div>
        <div className="space-y-1.5">
          <Label>Shop / Person</Label>
          <Input {...register("shopOrPerson")} placeholder="Al-Rehman Workshop" />
        </div>
        <div className="space-y-1.5">
          <Label>Serviced By</Label>
          <Select value={watch("maintenanceBy")} onValueChange={v => setValue("maintenanceBy", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="internal">Internal Workshop</SelectItem>
              <SelectItem value="external">External Workshop</SelectItem>
              <SelectItem value="dealer">Dealer Service</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Next Service Odometer</Label>
          <Input type="number" {...register("nextServiceOdometerKm")} placeholder="Optional" />
        </div>
        <div className="space-y-1.5">
          <Label>Next Service Due Date</Label>
          <Input type="date" {...register("nextServiceDueDate")} />
        </div>
      </div>
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={() => dispatch(closeFleetDrawer())}>Cancel</Button>
        <Button type="submit" disabled={isPending || !watch("vehicleId")}>
          {isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {mode === 'create' ? "Add Record" : "Save Changes"}
        </Button>
      </div>
    </form>
  )
}
