"use client"

import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query"
import { useEffect } from "react"
import { fleetApi } from "@/lib/api/fleet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import { useAppDispatch } from "@/lib/store"
import { closeFleetDrawer } from "@/lib/store/slices/ui-slice"
import { Loader2 } from "lucide-react"

const schema = z.object({
  vehicleId: z.string().min(1, "Vehicle is required"),
  destination: z.string().min(1, "Destination is required"),
  tripDate: z.string().min(1, "Date is required"),
  purposeOfVisit: z.string().optional().nullable(),
  driverName: z.string().optional().nullable(),
  meterOut: z.preprocess((val) => Number(val), z.number().min(0)),
  meterIn: z.preprocess((val) => val === "" || val === null ? undefined : Number(val), z.number().min(0).optional().nullable()),
  fuelAllottedLiters: z.preprocess((val) => val === "" || val === null ? undefined : Number(val), z.number().min(0).optional().nullable()),
  fuelCostPkr: z.preprocess((val) => val === "" || val === null ? undefined : Number(val), z.number().min(0).optional().nullable()),
  status: z.string().default("in_progress"),
})

type FormData = z.infer<typeof schema>

export default function TripForm({ data, mode }: { data?: any; mode: 'create' | 'edit' }) {
  const qc = useQueryClient()
  const dispatch = useAppDispatch()

  const { data: vehicles } = useQuery({ queryKey: ["vehicles", "dropdown"], queryFn: fleetApi.vehicles.dropdown })

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      vehicleId: "", destination: "", tripDate: new Date().toISOString().split('T')[0],
      meterOut: 0, status: "in_progress"
    }
  })

  useEffect(() => {
    if (data && mode === 'edit') {
      reset({
        vehicleId: data.vehicleId || data.vehicle?.id || "",
        destination: data.destination || "",
        tripDate: data.tripDate ? new Date(data.tripDate).toISOString().split('T')[0] : "",
        purposeOfVisit: data.purposeOfVisit || "",
        driverName: data.driverName || "",
        meterOut: data.meterOut || 0,
        meterIn: data.meterIn,
        fuelAllottedLiters: data.fuelAllottedLiters,
        fuelCostPkr: data.fuelCostPkr,
        status: data.status || "in_progress",
      })
    } else {
      reset({
        vehicleId: "", destination: "", tripDate: new Date().toISOString().split('T')[0],
        meterOut: 0, status: "in_progress"
      })
    }
  }, [data, mode, reset])

  const { mutate, isPending } = useMutation({
    mutationFn: (vals: FormData) => 
      mode === 'create' ? fleetApi.trips.create(vals as any) : fleetApi.trips.update(data.id, vals as any),
    onSuccess: () => {
      toast.success(mode === 'create' ? "Trip logged" : "Trip updated")
      qc.invalidateQueries({ queryKey: ["trips"] })
      dispatch(closeFleetDrawer())
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.message || "Something went wrong")
    }
  })

  return (
    <form onSubmit={handleSubmit(v => mutate(v))} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 space-y-1.5">
          <Label>Vehicle *</Label>
          <Select value={watch("vehicleId")} onValueChange={v => setValue("vehicleId", v)}>
            <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
            <SelectContent>
              {vehicles?.map(v => (
                <SelectItem key={v.id} value={v.id}>{v.registrationNumber} — {v.vehicleName}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.vehicleId && <p className="text-xs text-destructive">{errors.vehicleId.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Destination *</Label>
          <Input {...register("destination")} />
          {errors.destination && <p className="text-xs text-destructive">{errors.destination.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Trip Date *</Label>
          <Input type="date" {...register("tripDate")} />
          {errors.tripDate && <p className="text-xs text-destructive">{errors.tripDate.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>Meter Out *</Label>
          <Input type="number" {...register("meterOut")} />
        </div>
        <div className="space-y-1.5">
          <Label>Meter In</Label>
          <Input type="number" {...register("meterIn")} />
        </div>
        <div className="space-y-1.5">
          <Label>Driver Name</Label>
          <Input {...register("driverName")} />
        </div>
        <div className="space-y-1.5">
          <Label>Fuel Allotted (L)</Label>
          <Input type="number" {...register("fuelAllottedLiters")} />
        </div>
        <div className="space-y-1.5">
          <Label>Status</Label>
          <Select value={watch("status")} onValueChange={v => setValue("status", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button type="button" variant="outline" onClick={() => dispatch(closeFleetDrawer())}>Cancel</Button>
        <Button type="submit" disabled={isPending}>
          {isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {mode === 'create' ? "Log Trip" : "Save Changes"}
        </Button>
      </div>
    </form>
  )
}
