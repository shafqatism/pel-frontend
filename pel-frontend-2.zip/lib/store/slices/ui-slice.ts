import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface UIState {
  fleetDrawer: {
    isOpen: boolean;
    type: 'vehicle' | 'trip' | 'fuel' | 'maintenance' | 'assignment' | null;
    data: any | null;
    mode: 'create' | 'edit';
  };
}

const initialState: UIState = {
  fleetDrawer: {
    isOpen: false,
    type: null,
    data: null,
    mode: 'create',
  },
};

export const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    openFleetDrawer: (state, action: PayloadAction<{ type: UIState['fleetDrawer']['type']; data?: any; mode?: 'create' | 'edit' }>) => {
      state.fleetDrawer.isOpen = true;
      state.fleetDrawer.type = action.payload.type;
      state.fleetDrawer.data = action.payload.data || null;
      state.fleetDrawer.mode = action.payload.mode || 'create';
    },
    closeFleetDrawer: (state) => {
      state.fleetDrawer.isOpen = false;
      state.fleetDrawer.type = null;
      state.fleetDrawer.data = null;
    },
  },
});

export const { openFleetDrawer, closeFleetDrawer } = uiSlice.actions;
export default uiSlice.reducer;
